#!/usr/bin/env julia
using Plots, LaTeXStrings, JLD2

# Include energy analysis relative to this script reliably
include(joinpath(@__DIR__, "..", "src", "energy_analysis.jl"))
using Main.EnergyAnalysis

# Simple test: reproduce archive/plot_entropy_comparison_N.jl behavior (no normalization)
DATA_DIR = joinpath(@__DIR__, "..", "results", "raw", "alpha_sweep_N_periodic")
OUTPUT_DIR = joinpath(@__DIR__, "..", "results", "figures", "comparison")
DELTA_SMOOTH = 0.6
NS = [32, 64, 128, 256]

mkpath(OUTPUT_DIR)

println("Running entropy comparison test (unnormalized S) using files in: $DATA_DIR")

p = plot(legend=:topright,
         guidefont=font(16),
         tickfont=font(14),
         legendfont=font(12),
         framestyle=:box,
         grid=false,
         xscale=:log10,
         xlabel=L"t",
         ylabel=L"\bar{S}(t)",
         size=(900, 600))

colors = [:red, :blue, :green, :orange]

for (idx, N) in enumerate(NS)
    fname = joinpath(DATA_DIR, "results_springs_alpha_periodic_2026-04-03_N$(N).jld2")
    if !isfile(fname)
        println("  ⚠️  N=$N: file not found: $fname")
        continue
    end
    println("  ✓ Loading N=$N from $(basename(fname))")
    data = jldopen(fname, "r")
    results = data["results"]
    if isempty(results)
        println("    ✗ No results in file")
        close(data)
        continue
    end
    res = results[1]
    scaled_t = Float64.(Vector(res.scaled_t))
    modal_E = Float64.(Matrix(res.modal_E))
    if size(modal_E,1) > size(modal_E,2)
        modal_E = modal_E'
    end
    mask = scaled_t .> 0
    if sum(mask) == 0
        println("    ⚠️ N=$N: no positive times for log scale")
        close(data)
        continue
    end
    S = compute_entropy(modal_E, DELTA_SMOOTH)
    plot!(p, scaled_t[mask], S[mask], label="N=$N", lw=2, color=colors[idx])
    close(data)
end

mkpath(OUTPUT_DIR)
outf = joinpath(OUTPUT_DIR, "entropy_comparison_N_test_unnormalized.pdf")
savefig(p, outf)
println("Saved test figure: $outf")
