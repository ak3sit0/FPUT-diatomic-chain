# Run quick compatibility tests for plotting scripts using available TOML configs.
# Writes logs to results/logs/ and a summary file.

using TOML, Dates

CONFIG_DIRS = ["configs/pape", "configs/templates", "configs/templates/archive"]
SCRIPTS = Dict(
    "plot_dynamics" => "examples/plot_dynamics.jl",
    "plot_heatmap_grid" => "examples/plot_heatmap_grid.jl",
    "plot_resonance" => "examples/plot_resonance_level_curves.jl",
)

mkpath("results/logs")
summary_path = joinpath("results/logs", "plot_compat_summary_$(Dates.format(Dates.now(), "yyyy-mm-dd_HHMM")) .txt")
open(summary_path, "w") do sumio
    println(sumio, "Plot compatibility test run: $(Dates.now())")
    println(sumio, "Scanning config directories: ")

    configs = String[]
    for d in CONFIG_DIRS
        if isdir(d)
            for f in readdir(d)
                if endswith(f, ".toml")
                    push!(configs, joinpath(d, f))
                end
            end
        end
    end

    println(sumio, "Found $(length(configs)) config files")

    for cfg in configs
        println(sumio, "\n=== Config: $cfg ===")
        println("Testing: $cfg")
        toml = try TOML.parsefile(cfg) catch e; Dict() end
        data_tbl = get(toml, "data", Dict{String,Any}())
        input_file = get(data_tbl, "input_file", "")
        # Ensure absolute or workspace-relative path
        has_datafile = input_file != "" && isfile(input_file)

        for (name, script) in SCRIPTS
            logfile = replace(joinpath("results/logs", "$(basename(cfg))_$(name).log"), ' '=>"_")
            cmd = "julia --project=. $script $cfg > $logfile 2>&1"

            # Decide whether to run: heatmap & dynamics need data file
            if (name == "plot_dynamics" || name == "plot_heatmap_grid") && !has_datafile
                println(sumio, "SKIP $name (missing data input: $input_file)")
                continue
            end

            # Run and capture exit via shell; may take time
            println(sumio, "RUNNING $name -> log: $logfile")
            try
                run(`bash -lc $cmd`)
                println(sumio, "OK: $name")
            catch e
                println(sumio, "FAIL: $name -> see $logfile")
            end
        end
    end

    println(sumio, "\nDone.")
end

println("Compatibility tests launched. See summary: $summary_path")
