# Summarize compatibility test results from compat_tests log and individual logs
using Dates

logdir = "results/logs"
# find latest compat_tests log
logs = filter(f->endswith(f, ".log"), readdir(logdir))
compat = filter(f->occursin("compat_tests", f), logs)
isempty(compat) && error("No compat_tests log found in $logdir")
latest = sort(compat)[end]
path = joinpath(logdir, latest)

outpath = joinpath(logdir, "plot_compat_summary_parsed_$(Dates.format(now(), "yyyy-mm-dd_HHMM")).txt")
# Inspect individual log files in the logdir matching *_plot_*.log
files = filter(f->occursin("_plot_", f) && endswith(f, ".log"), readdir(logdir))
stats = Dict(:OK=>0, :FAIL=>0, :EMPTY=>0, :UNKNOWN=>0)
open(outpath, "w") do out
        println(out, "Compatibility summary generated: $(now())")
        println(out, "Source compat log: $path")
        println(out, "")
        println(out, "Per-log summary:")
        for f in sort(files)
            fp = joinpath(logdir, f)
            sz = stat(fp).size
            if sz == 0
                println(out, "- $f: EMPTY (likely skipped)")
                stats[:EMPTY] += 1
                continue
            end
            txt = read(fp, String)
            if occursin("Saved:", txt)
                println(out, "- $f: OK (Saved output)")
                stats[:OK] += 1
            elseif occursin("ERROR", txt) || occursin("ERROR:", txt) || occursin("ERROR ", txt) || occursin("Exception", txt)
                println(out, "- $f: FAIL (error in log)")
                stats[:FAIL] += 1
            else
                println(out, "- $f: UNKNOWN (see log)")
                stats[:UNKNOWN] += 1
            end
        end

        println(out, "")
        println(out, "Totals: OK=$(stats[:OK]) | FAIL=$(stats[:FAIL]) | EMPTY=$(stats[:EMPTY]) | UNKNOWN=$(stats[:UNKNOWN])")
    end
println("Summary written to: $outpath")
