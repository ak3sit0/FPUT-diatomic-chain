# Unified dynamics plotting script: entropy / xi / modal energies
# Usage: julia --project=. examples/plot_dynamics.jl configs/templates/master_plot.toml

using Plots, LaTeXStrings, JLD2, Statistics, TOML, Dates
include("../src/config.jl"); using Main.Config
include("../src/parameters.jl"); using Main.Parameters
include("../src/energy_analysis.jl"); using Main.EnergyAnalysis

const SMOOTH_DELTA_DEFAULT = 0.6
const EPS = 1e-18

function expand_input_pattern(pattern::String)
    # If pattern is an exact file, return it; if contains wildcard, expand against dir
    if isfile(pattern)
        return [pattern]
    end
    if !occursin("*", pattern)
        # maybe it's a directory
        if isdir(pattern)
            files = sort(filter(f->endswith(f, ".jld2"), readdir(pattern; join=true)))
            return files
        else
            error("Input pattern not found: $pattern")
        end
    end
    dir = dirname(pattern)
    pat = basename(pattern)
    # Build simple regex from wildcard (ensure full match manually)
    regex = Regex("^" * replace(pat, "*"=>".*"))
    files = filter(f->(m = match(regex, f); m !== nothing && m.match == f), readdir(dir))
    return sort(joinpath(dir, f) for f in files)
end

function smooth_modal_energies(modal_E::AbstractMatrix, delta::Float64)
    smoothed = similar(modal_E, Float64)
    for i in 1:size(modal_E, 1)
        smoothed[i, :] = EnergyAnalysis.sliding_delta_average(Float64.(modal_E[i, :]), delta)
    end
    return smoothed
end

function entropy_from_smooth(E_smooth)
    total_E = sum(E_smooth, dims=1)
    p = E_smooth ./ (total_E .+ EPS)
    p_safe = p .+ (p .== 0.0)
    -vec(sum(p .* log.(p_safe), dims=1))
end

function compute_entropy_smooth(modal_E::Matrix; delta::Float64=SMOOTH_DELTA_DEFAULT)
    E_smooth = smooth_modal_energies(modal_E, delta)
    entropy_from_smooth(E_smooth)
end

function detect_N_from_modal_E(modal_E)
    # modal_E dimensions are (modes x time) typically; N = number of modes
    size(modal_E, 1)
end

function main()
    if isempty(ARGS)
        error("Usage: julia --project=. examples/plot_dynamics.jl <plot_config.toml>")
    end
    cfg_path = ARGS[1]
    pcfg = Config.load_plot_config(cfg_path)

    # Determine input files (allow wildcard or directory)
    input_field = pcfg.input_file
    input_files = typeof(input_field) <: AbstractString ? expand_input_pattern(input_field) : String[]
    isempty(input_files) && error("No input .jld2 files found for pattern: $(pcfg.input_file)")

    # ensure output dir exists (PlotConfig provides sensible defaults)
    mkpath(pcfg.outdir_entropy)

    # read raw TOML to get flags not present in PlotConfig struct (for backward-compatibility)
    toml = TOML.parsefile(cfg_path)
    analysis_tbl = get(toml, "analysis", Dict{String,Any}())
    normalize_by_logN = haskey(analysis_tbl, "normalize_by_logN") ? Bool(analysis_tbl["normalize_by_logN"]) : false
    t_min_cfg = haskey(toml, "plot") && haskey(toml["plot"], "t_min") ? Float64(toml["plot"]["t_min"]) : pcfg.t_min
    t_max_cfg = haskey(toml, "plot") && haskey(toml["plot"], "t_max") ? (Float64(toml["plot"]["t_max"]) >= 1e17 ? Inf : Float64(toml["plot"]["t_max"])) : pcfg.t_max
    time_sub = haskey(toml, "plot") && haskey(toml["plot"], "time_subsample") ? Int(toml["plot"]["time_subsample"]) : pcfg.time_subsample

    p = plot(xlabel=L"t", ylabel=L"\bar{S}(t)", legend=:bottomright, framestyle=:box,
             grid=false, xscale=:log10, size=(900,600), title="Entropy (smoothed)")

    colors = [:black, :blue, :red, :green, :orange, :purple]

    for (i, fpath) in enumerate(input_files)
        println("Loading: $fpath")
        data = load(fpath)
        results = data["results"]
        # If multiple runs in file, pick first or average? we'll plot first matching param
        for res in results
            t_full = Float64.(Vector(res.scaled_t))
            E_full = Float64.(Matrix(res.modal_E))
            if size(E_full, 1) > size(E_full, 2)
                E_full = E_full'
            end
            # select valid time indices within configured window and positive for log-scale compatibility
            idxs = findall(t -> isfinite(t) && t > 1e-12 && t >= t_min_cfg && t <= t_max_cfg, t_full)
            isempty(idxs) && continue
            idxs = idxs[1:time_sub:end]
            S = compute_entropy_smooth(E_full[:, idxs]; delta=pcfg.smooth_delta)
            # Normalization option (default true)
            N = detect_N_from_modal_E(E_full)
            if normalize_by_logN
                S = S ./ log(N)
            end
            # choose xscale depending on minimum time value
            tplot = t_full[idxs]
            if minimum(tplot) <= 0
                xaxis_scale = :identity
            else
                xaxis_scale = :log10
            end
            plot!(p, tplot, S, label=basename(fpath), lw=2, color=colors[mod1(i, length(colors))], xscale=xaxis_scale)
            break
        end
    end

    outname = joinpath(pcfg.outdir_entropy, "entropy_dynamics_$(Dates.format(Dates.now(), "yyyy-mm-dd_HHMM")) .pdf")
    # sanitize filename
    outname = replace(outname, ' '=>"_")
    savefig(p, outname)
    println("Saved: $outname")
end

if abspath(PROGRAM_FILE) == @__FILE__
    main()
end
