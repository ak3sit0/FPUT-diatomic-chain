#!/usr/bin/env julia
using TOML, Dates, JLD2
include(joinpath(@__DIR__, "..", "src", "config.jl"))
using Main.Config
include(joinpath(@__DIR__, "..", "src", "simulation_runner.jl"))
using Main.SimulationRunner

function compute_omega_init(N::Int, init_mode::Int)
    # Model uses ω_k = 2 * sin(π * k / N)
    return 2 * sin(pi * init_mode / N)
end

function main()
    if length(ARGS) < 1
        println("Usage: julia --project=. scripts/run_with_cycles.jl <experiment_config.toml>")
        return
    end
    cfg_path = ARGS[1]
    cfg = Config.load_experiment_config(cfg_path)

    # Read cycles_target from TOML (may not be present)
    raw = TOML.parsefile(cfg_path)
    cycles = haskey(raw["simulation"], "cycles_target") ? Float64(raw["simulation"]["cycles_target"]) : nothing
    if cycles === nothing
        # Fallback: use provided TMAX
        TMAX = cfg.TMAX
        println("No cycles_target found; using TMAX from config: $TMAX")
    else
        init_mode = cfg.init_mode === nothing ? 1 : cfg.init_mode
        ω = compute_omega_init(cfg.N, init_mode)
        if ω <= 0
            error("Computed non-positive omega_init: $ω")
        end
        TMAX = cycles * 2 * pi / ω
        println("Computed TMAX from cycles_target=$cycles: TMAX=$TMAX (omega_init=$ω)")
    end

    # Prepare simulation parameters
    N = cfg.N
    DT = cfg.DT
    save_every = cfg.save_every
    energy = cfg.initial_energy
    init_mode = cfg.init_mode === nothing ? 2 : cfg.init_mode
    boundary = cfg.boundary

    # pick nonlinear parameter value
    alpha = 0.0
    beta = 0.0
    if cfg.nonlinear == :alpha
        alpha = cfg.param_values[1]
    elseif cfg.nonlinear == :beta
        beta = cfg.param_values[1]
    end

    # delta/inhomogeneity
    DeltaK = isempty(cfg.delta_values) ? 0.0 : cfg.delta_values[1]

    println("Running simulation: N=$N, TMAX=$TMAX, DT=$DT, save_every=$save_every, init_mode=$init_mode")

    energies, scaled_t, freqs, v_final, q_final = SimulationRunner.run_and_analyze(
        N=N, TMAX=TMAX, DT=DT, alpha=alpha, beta=beta, DeltaK=DeltaK,
        boundary=Symbol(string(boundary)), init_mode=init_mode, energy=energy, save_every=save_every)

    # Save output with metadata
    outdir = Config.config_outdir(cfg)
    mkpath(outdir)
    outpath = joinpath(outdir, "results_$(cfg.name)_$(Dates.format(now(), "yyyy-mm-dd_HHMM")).jld2")

    Config.save_with_metadata(outpath, cfg_path;
        results = [Dict(:param => cfg.param_values, :Delta => cfg.delta_values, :scaled_t => scaled_t, :modal_E => energies)],
        frequencies = freqs,
        final_q = q_final,
        final_v = v_final)

    println("Saved results to: $outpath")
end

if abspath(PROGRAM_FILE) == @__FILE__
    main()
end
