#!/usr/bin/env julia
using TOML, Dates

base_toml = "configs/pape/alpha_sweep_N_periodic_cycles.toml"
out_tmp_dir = joinpath(@__DIR__, "..", "tmp_configs")
isdir(out_tmp_dir) || mkpath(out_tmp_dir)

function write_tmp_toml(base::String, N::Int, cycles::Float64)
    d = TOML.parsefile(base)
    d["physics"]["N"] = N
    d["experiment"]["name"] = "$(d["experiment"]["name"])_N$(N)"
    d["simulation"]["cycles_target"] = cycles
    tmp = joinpath(out_tmp_dir, "tmp_cycles_$(Dates.format(now(),"yyyyMMdd_HHMMSS"))_N$(N).toml")
    open(tmp, "w") do io
        TOML.print(io, d)
    end
    return tmp
end

function run_single(N::Int, cycles::Float64)
    tmp = write_tmp_toml(base_toml, N, cycles)
    println("[N=$N] Starting with tmp config: $tmp")
    cmd = `julia --project=. scripts/run_with_cycles.jl $tmp`
    try
        run(cmd)
        println("[N=$N] Completed successfully")
    catch e
        println("[N=$N] Error: $e")
    end
end

function main()
    Ns = length(ARGS) >= 1 ? parse.(Int, split(ARGS[1], ",")) : [32,64,128,256]
    cycles = length(ARGS) >= 2 ? parse(Float64, ARGS[2]) : 1e3

    println("Running cycles test for N = $(Ns) with cycles_target = $cycles (in parallel)")
    
    # Run all N in parallel using asyncmap
    asyncmap(N -> run_single(N, cycles), Ns)
    
    println("All tasks done")
end

if abspath(PROGRAM_FILE) == @__FILE__
    main()
end
